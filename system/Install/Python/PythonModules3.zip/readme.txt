python directory structure

DLLs dir:
  Library directory used by python.
  python exensions (.pyd) from cvs can be placed here
  
Lib dir:
  Library directory used by python.
  Here can new packages or modules be installed by the user.
